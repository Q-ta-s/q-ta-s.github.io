#include <stdio.h>
#include <stdlib.h>

typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;

int main (int argc, char **argv) {
	FILE* fileHandle =fopen(argv[1], "r+b");
	if (fileHandle) {
		size_t fileSize;
		uint8_t* fileData;
		fseek(fileHandle, 0, SEEK_END);
		fileSize =ftell(fileHandle);
		fileData =malloc(fileSize);
		if (fileData) {
			uint8_t* footer;
			fseek(fileHandle, 0, SEEK_SET);
			fread(fileData, 1, fileSize, fileHandle);
			
			footer =fileData +fileSize -0x16;
			if (footer >=fileData && footer[0] =='W' && footer[1] =='Q' && footer[2] =='W' && footer[3] ==0x01) {
				uint16_t numberOfFiles;
				size_t ofs;
				uint8_t* directory;
				footer[0] ='P';
				footer[1] ='K';
				footer[2] =5;
				footer[3] =6;
				numberOfFiles =footer[0x08] | footer[0x09] <<8;
				ofs = fileSize - 0x16 - (footer[0x10] | footer[0x11] <<8 | footer[0x12] <<16 | footer[0x13] <<24) -
					(footer[0xc] | footer[0xd] <<8 | footer[0xe] <<16 | footer[0xf] <<24);
				directory =fileData + ofs + (footer[0x10] | footer[0x11] <<8 | footer[0x12] <<16 | footer[0x13] <<24);
				while (numberOfFiles && (directory +0x2E) <footer) {
					if (directory[0] =='W' && directory[1] =='Q' && directory[2] =='W' && directory[3] ==0x02) {
						uint8_t* packedFile;
						int nameLength, extraLength, i;
						directory[0] ='P';
						directory[1] ='K';
						directory[2] =1;
						directory[3] =2;
						packedFile =fileData + ofs + (directory[0x2A] | directory[0x2B] <<8 | directory[0x2C] <<16 | directory[0x2D] <<24);
						if (packedFile[0] =='W' && packedFile[1] =='Q' && packedFile[2] =='W' && packedFile[3] ==0x03) {
							int nameLength;
							packedFile[0] ='P';
							packedFile[1] ='K';
							packedFile[2] =3;
							packedFile[3] =4;
							nameLength =packedFile[0x1A] | packedFile[0x1B] <<8;
							for (i =0; i <nameLength; i++) packedFile[0x1E +i] ^=packedFile[0x1E +i] &0x80? 0xE5: 0x5A;
						} else {
							fprintf(stderr, "%s: invalid file signature at offset $%05lX\n", argv[1], packedFile -fileData);
							fclose(fileHandle);
							return EXIT_FAILURE;
						}
						nameLength =directory[0x1C] | directory[0x1D] <<8;
						extraLength =directory[0x1E] | directory[0x1F] <<8;
						for (i =0; i <nameLength; i++) directory[0x2E +i] ^=directory[0x2E +i] &0x80? 0xE5: 0x5A;
						directory +=0x2E +nameLength +extraLength;
					} else {
						fprintf(stderr, "%s: invalid directory signature %02X%02X%02X%02X at offset $%05lX\n", argv[1], directory[0], directory[1], directory[2], directory[3], directory -fileData);
						fclose(fileHandle);
						return EXIT_FAILURE;
					}
				}
				fseek(fileHandle, 0, SEEK_SET);
				fwrite(fileData, 1, fileSize, fileHandle);
			} else {
				fprintf(stderr, "%s: not a WQW file\n", argv[1]);
				fclose(fileHandle);
				return EXIT_FAILURE;
			}			
			fclose(fileHandle);
			return EXIT_SUCCESS;
		} else {
			fprintf(stderr, "%s: could not allocate %zu bytes\n", argv[1], fileSize);
			fclose(fileHandle);
			return EXIT_FAILURE;
		}
	} else {
		fprintf(stderr, "Error opening %s\n", argv[1]);
		return EXIT_FAILURE;
	}
}