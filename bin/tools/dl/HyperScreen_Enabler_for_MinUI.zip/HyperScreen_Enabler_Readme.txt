- HyperScreen Enabler

This batch file is a tool to enable "HyperScreen". 
Copy the "Qs_tool" folder into the "Resources" folder on the SD card,
and double-click the batch file to enable HyperScreen. 
To disable the HyperScreen (revert), run the batch file again.
